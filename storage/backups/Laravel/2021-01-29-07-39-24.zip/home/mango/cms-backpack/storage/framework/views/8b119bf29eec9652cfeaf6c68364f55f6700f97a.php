<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class="la la-home nav-icon"></i> <?php echo e(trans('backpack::base.dashboard')); ?></a></li>
<li class="nav-item nav-dropdown">
    <a class="nav-link nav-dropdown-toggle" href="#"><i class="nav-icon la la-users"></i> Authorizations</a>
    <ul class="nav-dropdown-items">
        <li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('user')); ?>"><i class="nav-icon la la-user"></i> <span>Users</span></a></li>
        <?php if(backpack_user()->hasRole("Admin")): ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('role')); ?>"><i class="nav-icon la la-id-badge"></i> <span>Roles</span></a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('permission')); ?>"><i class="nav-icon la la-key"></i> <span>Permissions</span></a></li>
        <?php endif; ?>
    </ul>
</li>
<li class="nav-item nav-dropdown">
    <a class="nav-link nav-dropdown-toggle" href="#"><i class="nav-icon la la-newspaper-o"></i>Posts</a>
    <ul class="nav-dropdown-items">
        <li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('post')); ?>'><i class='nav-icon la la-question'></i> Posts</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('category')); ?>"><i class="nav-icon la la-list"></i> Categories</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('tag')); ?>"><i class="nav-icon la la-tag"></i> Tags</a></li>
    </ul>
</li>



<?php /**PATH /home/mango/cms-backpack/resources/views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>