<?php if(backpack_user()->can("update",$entry)): ?>
<a href="<?php echo e(url($crud->route.'/'.$entry->getKey().'/edit')); ?> " class="btn btn-sm btn-link"><i class="la la-edit"></i>Edit</a>
<?php endif; ?>

<?php /**PATH /home/mango/cms-backpack/resources/views/vendor/backpack/crud/buttons/edit.blade.php ENDPATH**/ ?>