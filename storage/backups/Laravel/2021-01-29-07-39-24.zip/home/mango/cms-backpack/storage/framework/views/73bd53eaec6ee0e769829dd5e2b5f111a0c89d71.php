<!-- This file is used to store topbar (left) items -->


<?php if(backpack_user()->isImpersonating()): ?>
    <li><a href="<?php echo e(url('admin/stop-impersonating')); ?>">Stop Impersonating</a></li>
<?php endif; ?>
<?php /**PATH /home/mango/cms-backpack/resources/views/vendor/backpack/base/inc/topbar_left_content.blade.php ENDPATH**/ ?>