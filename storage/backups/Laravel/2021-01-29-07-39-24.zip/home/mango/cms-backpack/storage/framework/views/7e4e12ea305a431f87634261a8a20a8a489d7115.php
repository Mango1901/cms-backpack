<?php
  $defaultBreadcrumbs = [
    trans('backpack::crud.admin') => url(config('backpack.base.route_prefix'), 'dashboard'),
    $crud->entity_name_plural => url($crud->route),
    trans('revise-operation::revise.revisions') => false,
  ];

  // if breadcrumbs aren't defined in the CrudController, use the default breadcrumbs
  $breadcrumbs = $breadcrumbs ?? $defaultBreadcrumbs;

  $heading = $crud->getHeading() ?? $crud->entity_name_plural;
  $subheading = $crud->getSubheading() ?? method_exists($entry, 'identifiableName') ? trans('revise-operation::revise.revisions_for').' "'.$entry->identifiableName().'"' : trans('revise-operation::revise.revisions');
?>

<?php $__env->startSection('header'); ?>
  <div class="container-fluid">
    <h2>
        <span class="text-capitalize"><?php echo $heading; ?></span>
        <small><?php echo $subheading; ?>.</small>

        <?php if($crud->hasAccess('list')): ?>
          <small><a href="<?php echo e(url($crud->route)); ?>" class="hidden-print font-sm"><i class="la la-angle-double-left"></i> <?php echo e(trans('backpack::crud.back_to_all')); ?> <span><?php echo e($crud->entity_name_plural); ?></span></a></small>
        <?php endif; ?>
    </h2>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row m-t-20">
  <div class="<?php echo e($crud->get('revise.timelineContentClass') ?? 'col-md-12'); ?>">
    <!-- Default box -->

    <?php if(!count($revisions)): ?>
      <div class="card">
        <div class="card-header with-border">
          <h3 class="card-title"><?php echo e(trans('revise-operation::revise.no_revisions')); ?></h3>
        </div>
      </div>
    <?php else: ?>
      <?php echo $__env->make('revise-operation::revision_timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('after_styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('packages/backpack/crud/css/crud.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('packages/backpack/crud/css/revisions.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
  <script src="<?php echo e(asset('packages/backpack/crud/js/crud.js')); ?>"></script>
  <script src="<?php echo e(asset('packages/backpack/crud/js/revisions.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_view('blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mango/cms-backpack/vendor/backpack/revise-operation/src/../resources/views/revisions.blade.php ENDPATH**/ ?>