        <meta charset="utf-8">
        <title>File Manager</title>

        <!-- elFinder CSS (REQUIRED) -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset($dir.'/css/elfinder.min.css')); ?>">
        
        <link rel="stylesheet" type="text/css" href="<?= asset('packages/backpack/filemanager/themes/Backpack/elfinder.backpack.theme.css') ?>">
        
        
        <?php /**PATH /home/mango/cms-backpack/resources/views/vendor/elfinder/common_styles.blade.php ENDPATH**/ ?>