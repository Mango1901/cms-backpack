<?php if($crud->hasAccess('impersonate') && backpack_user()->can("update",$entry)): ?>
   <a href="<?php echo e(url($crud->route.'/'.$entry->getKey().'/impersonate')); ?> " class="btn btn-sm btn-link <?php echo e(backpack_user()->id == $entry->getKey()? 'disabled': ''); ?>"><i class="fa fa-user"></i>Impersonate</a>
<?php endif; ?>

<?php /**PATH /home/mango/cms-backpack/resources/views/vendor/backpack/crud/buttons/impersonate.blade.php ENDPATH**/ ?>