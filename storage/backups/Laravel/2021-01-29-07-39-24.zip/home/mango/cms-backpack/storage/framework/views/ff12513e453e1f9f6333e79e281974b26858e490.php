data-inline-create-route="<?php echo e($field['inline_create']['create_route'] ?? false); ?>"
data-inline-modal-route="<?php echo e($field['inline_create']['modal_route'] ?? false); ?>"

data-field-related-name="<?php echo e($field['inline_create']['entity']); ?>"
data-inline-create-button="<?php echo e($field['inline_create']['entity']); ?>-inline-create-<?php echo e($field['name']); ?>"
data-inline-allow-create="<?php echo e(var_export($activeInlineCreate)); ?>"
data-parent-loaded-fields="<?php echo e(json_encode(array_unique(array_column($crud->fields(),'type')))); ?>"
<?php /**PATH /home/mango/cms-backpack/vendor/backpack/crud/src/resources/views/crud/fields/relationship/field_attributes.blade.php ENDPATH**/ ?>