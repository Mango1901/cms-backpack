<div class="m-t-10 m-b-10 p-l-10 p-r-10 p-t-10 p-b-10">
    <div class="row">
        <div class="col-md-12">
            <small>Use the <span class="label label-default">details_row</span> functionality to show more information about the entry, when that information does not fit inside the table column.</small><br><br>
            <strong>Title:</strong> <?php echo e($entry->title); ?> <br>
            <strong>Description:</strong> <?php echo $entry->description; ?> <br>
            <strong>Format:</strong> <?php echo e($entry->format); ?> <br>
            <strong>created_at:</strong> <?php echo e($entry->created_at); ?> <br>
            <strong>Excerpt:</strong> <?php echo e($entry->excerpt); ?> <br>
            <strong>Url:</strong> <?php echo e($entry->url); ?> <br>
            etc.
        </div>
    </div>
</div>
<div class="clearfix"></div>
<?php /**PATH /home/mango/cms-backpack/resources/views/vendor/backpack/crud/details_row/post.blade.php ENDPATH**/ ?>