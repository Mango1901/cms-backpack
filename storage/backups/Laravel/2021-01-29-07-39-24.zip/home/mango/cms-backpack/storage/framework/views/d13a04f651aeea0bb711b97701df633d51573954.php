
<div id="timeline">
<?php $__currentLoopData = $revisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revisionDate => $dateRevisions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h5 class="text-primary">
        <?php echo e(Carbon\Carbon::parse($revisionDate)->isoFormat(config('backpack.base.default_date_format'))); ?>

      </h5>

  <?php $__currentLoopData = $dateRevisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card timeline-item-wrap">

      <?php if($history->key == 'created_at' && !$history->old_value): ?>
        <div class="card-header">
          <strong class="time"><i class="la la-clock"></i> <?php echo e(date('h:ia', strtotime($history->created_at))); ?></strong> -
          <?php echo e($history->userResponsible()?$history->userResponsible()->name:trans('revise-operation::revise.guest_user')); ?> <?php echo e(trans('revise-operation::revise.created_this')); ?> <?php echo e($crud->entity_name); ?>

        </div>
      <?php else: ?>
        <div class="card-header">
          <strong class="time"><i class="la la-clock"></i> <?php echo e(date('h:ia', strtotime($history->created_at))); ?></strong> -
          <?php echo e($history->userResponsible()?$history->userResponsible()->name:trans('revise-operation::revise.guest_user')); ?> <?php echo e(trans('revise-operation::revise.changed_the')); ?> <?php echo e($history->fieldName()); ?>

          <div class="card-header-actions">
            <form class="card-header-action" method="post" action="<?php echo e(url(\Request::url().'/'.$history->id.'/restore')); ?>">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-outline-danger btn-sm restore-btn" data-entry-id="<?php echo e($entry->id); ?>" data-revision-id="<?php echo e($history->id); ?>" onclick="onRestoreClick(event)">
                <i class="la la-undo"></i> <?php echo e(trans('revise-operation::revise.undo')); ?></button>
              </form>
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-6"><?php echo e(mb_ucfirst(trans('revise-operation::revise.from'))); ?>:</div>
            <div class="col-md-6"><?php echo e(mb_ucfirst(trans('revise-operation::revise.to'))); ?>:</div>
          </div>
          <div class="row">
            <div class="col-md-6"><div class="alert alert-danger" style="overflow: hidden;"><?php echo e($history->oldValue()); ?></div></div>
            <div class="col-md-6"><div class="alert alert-success" style="overflow: hidden;"><?php echo e($history->newValue()); ?></div></div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->startSection('after_scripts'); ?>
  <script type="text/javascript">
    $.ajaxPrefilter(function(options, originalOptions, xhr) {
        var token = $('meta[name="csrf_token"]').attr('content');

        if (token) {
              return xhr.setRequestHeader('X-XSRF-TOKEN', token);
        }
    });
    function onRestoreClick(e) {
      e.preventDefault();
      var entryId = $(e.target).attr('data-entry-id');
      var revisionId = $(e.target).attr('data-revision-id');
      $.ajax('<?php echo e(url(\Request::url()).'/'); ?>' +  revisionId + '/restore', {
        method: 'POST',
        data: {
          revision_id: revisionId
        },
        success: function(revisionTimeline) {
          // Replace the revision list with the updated revision list
          $('#timeline').replaceWith(revisionTimeline);

          // Animate the new revision in (by sliding)
          $('.timeline-item-wrap').first().addClass('fadein');

          // Show a green notification bubble
          new Noty({
              type: "success",
              text: "<?php echo e(trans('revise-operation::revise.revision_restored')); ?>"
          }).show();
        },
        error: function(data) {
          // Show a red notification bubble
          new Noty({
              type: "error",
              text: data.responseJSON.message
          }).show();
        }
      });
  }
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_styles'); ?>
  
  <style>
     .timeline-item-wrap.fadein {
      -webkit-animation: restore-fade-in 3s;
              animation: restore-fade-in 3s;
    }
    @-webkit-keyframes restore-fade-in {
      from {opacity: 0}
      to {opacity: 1}
    }
      @keyframes  restore-fade-in {
        from {opacity: 0}
        to {opacity: 1}
    }
  </style>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/mango/cms-backpack/vendor/backpack/revise-operation/src/../resources/views/revision_timeline.blade.php ENDPATH**/ ?>