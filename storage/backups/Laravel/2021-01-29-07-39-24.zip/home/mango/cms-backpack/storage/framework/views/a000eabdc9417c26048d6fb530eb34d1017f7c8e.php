<?php

    $loadedFields = json_decode($parentLoadedFields);

    //mark parent crud fields as loaded.
    foreach($loadedFields as $loadedField) {
        $crud->markFieldTypeAsLoaded($loadedField);
    }

?>
<div class="modal fade" id="inline-create-dialog" tabindex="0" role="dialog" aria-labelledby="<?php echo e($entity); ?>-inline-create-dialog-label" aria-hidden="true">
<div class="<?php echo e($modalClass); ?>" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="<?php echo e($entity); ?>-inline-create-dialog-label">
            <?php echo $crud->getSubheading() ?? trans('backpack::crud.add').' '.$crud->entity_name; ?>

          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body bg-light">
            <form method="post"
            id="<?php echo e($entity); ?>-inline-create-form"
            action="#"
            onsubmit="return false"
          <?php if($crud->hasUploadFields('create')): ?>
          enctype="multipart/form-data"
          <?php endif; ?>
            >
        <?php echo csrf_field(); ?>


        <!-- load the view from the application if it exists, otherwise load the one in the package -->
        <?php if(view()->exists('vendor.backpack.crud.fields.relationship.form_content')): ?>
            <?php echo $__env->make('vendor.backpack.crud.fields.relationship.form_content', [ 'fields' => $fields, 'action' => $action], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('crud::fields.relationship.form_content', [ 'fields' => $fields, 'action' => $action], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>


    </form>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="cancelButton"><?php echo e(trans('backpack::crud.cancel')); ?></button>
          <button type="button" class="btn btn-primary" id="saveButton"><?php echo e(trans('backpack::crud.save')); ?></button>
        </div>
      </div>
    </div>
  </div>



<?php /**PATH /home/mango/cms-backpack/vendor/backpack/crud/src/resources/views/crud/fields/relationship/inline_create_modal.blade.php ENDPATH**/ ?>