<?php

return [
    "post_thumb"=>env("DISK_NAME","uploads"),
];
